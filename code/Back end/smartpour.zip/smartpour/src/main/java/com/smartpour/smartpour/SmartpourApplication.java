package com.smartpour.smartpour;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartpourApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartpourApplication.class, args);
	}

}
