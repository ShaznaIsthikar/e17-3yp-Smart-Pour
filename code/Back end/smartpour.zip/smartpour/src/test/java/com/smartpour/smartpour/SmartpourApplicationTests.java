package com.smartpour.smartpour;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartpourApplicationTests {

	@Test
	void contextLoads() {
	}

}
