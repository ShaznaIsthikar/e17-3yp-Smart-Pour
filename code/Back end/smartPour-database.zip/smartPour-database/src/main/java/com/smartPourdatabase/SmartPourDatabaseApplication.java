package com.smartPourdatabase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartPourDatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartPourDatabaseApplication.class, args);
	}

}
